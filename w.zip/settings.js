/*

  !- Credits By BOLD
  https://wa.me/6285283253700
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6287855076857'
global.versi = "v1"
global.namaOwner = "AunuXdev"
global.packname = 'AunuHost'
global.botname = 'AunuCloudBot'
global.botname2 = 'AunuCpanel'
global.creator = '6287855076857@s.whatsapp.net'
global.author = 'AunuHost'

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = ""
global.linkSaluran2 = ""
global.idSaluran = "0@newsletter"
global.namaSaluran = "AunuTech"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "08"
global.ovo = "08"
global.gopay = "08"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://files.catbox.moe/spv59z.jpg", 
reply: "https://files.catbox.moe/spv59z.jpg", 
logo: "https://files.catbox.moe/spv59z.jpg", 
qris: "https://files.catbox.moe/spv59z.jpg"
}

//~~~~~~~~~ Settings Api Panel ~~~~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://dash.aunuhost.web.id" //domain mu, jangan kasih garis miring ( / ) dibelakang domain
global.apikey = "ptla_NbRnkzf2KHNIGmeLBZqfbZ6vHw1CBncqGHEQbmdMN2z" //ptla mu
global.capikey = "ptlc_gELO2nEzGKyeTFUQaK8KH76pSqFwPce5TblcnhLg3Ct" //ptlc mu

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "2" // Location ID
global.domainV2 = "https://dash.aunuhost.web.id" //domain mu, jangan kasih garis miring ( / ) dibelakang domain
global.apikeyV2 = "ptla_NbRnkzf2KHNIGmeLBZqfbZ6vHw1CBncqGHEQbmdMN2z" //ptla
global.capikeyV2 = "ptlc_gELO2nEzGKyeTFUQaK8KH76pSqFwPce5TblcnhLg3Ct" //ptlc

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV3 = "15" // Egg ID
global.nestidV3 = "5" // nest ID
global.locV3 = "3" // Location ID
global.domainV3 = "https://dash.aunuhost.web.id" //domain mu, jangan kasih garis miring ( / ) dibelakang domain
global.apikeyV3 = "ptla_NbRnkzf2KHNIGmeLBZqfbZ6vHw1CBncqGHEQbmdMN2z" //ptla
global.capikeyV3 = "ptlc_gELO2nEzGKyeTFUQaK8KH76pSqFwPce5TblcnhLg3Ct" //ptlc

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV4 = "15" // Egg ID
global.nestidV4 = "5" // nest ID
global.locV4 = "4" // Location ID
global.domainV4 = "https://dash.aunuhost.web.id" //domain mu, jangan kasih garis miring ( / ) dibelakang domain
global.apikeyV4 = "ptla_NbRnkzf2KHNIGmeLBZqfbZ6vHw1CBncqGHEQbmdMN2z" //ptla
global.capikeyV4 = "ptlc_gELO2nEzGKyeTFUQaK8KH76pSqFwPce5TblcnhLg3Ct" //ptlc
//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk AunuHost saja!",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk Admin Saja!",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium",
	wait: 'Loading...',
	error: 'Error!',
	done: 'sukses Kak'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})